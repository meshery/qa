import { expect, test } from "@playwright/test";
import {
  createAuthFlowHandlers,
  expectNoBrowserKratosRequest,
  mockAuthFlowResponse,
  passkeyRemoveNode,
  passkeySettingsNodes,
  stubPostAuthLanding,
  type AuthFlowNode,
  type SubmitLogEntry
} from "../helpers/auth-flow";
import { createFallbackHandlers, mockApi } from "../helpers/network";

// passkey-settings.spec.ts covers the /security/passkeys management page
// (issue #6478, spec §7.4 Tier A — mocked): the settings flow filtered
// to the `passkey` group lists registered passkeys (display name +
// added date), offers "Add a passkey", and removes via an in-place
// submit (`method=passkey` + `passkey_remove=<hex id>`).
//
// The custom-domain variant asserts the page's fallback (no list, no
// trigger) when `passkeysAvailable` is false. Every test asserts the
// topology invariant: no browser→Kratos request.

const stubCreate = () =>
  `
  const toBuffer = (bytes) => new Uint8Array(bytes).buffer;
  window.PublicKeyCredential = class {
    static async isConditionalMediationAvailable() { return false; }
  };
  Object.defineProperty(window.navigator, "credentials", {
    value: {
      get: async () => { throw new DOMException("Not implemented.", "NotSupportedError"); },
      create: async () => ({
        id: "test-credential-id",
        rawId: toBuffer([1, 2, 3]),
        type: "public-key",
        response: {
          clientDataJSON: toBuffer([4, 5]),
          attestationObject: toBuffer([6, 7, 8]),
          getTransports: () => ["internal"]
        }
      })
    },
    configurable: true
  });
  `;

const submitBodyParam = (body: string, name: string) =>
  new URLSearchParams(body).get(name);

// The CSRF node the settings flow carries (group "default", rescued
// through the filter by the hidden-node rule). Specs that hand-roll a
// post-submit flow via mockAuthFlowResponse({ nodes }) need it, since a
// custom node set replaces the defaults.
const csrfNode: AuthFlowNode = {
  type: "input",
  group: "default",
  attributes: {
    name: "csrf_token",
    type: "hidden",
    value: "test-csrf-token",
    required: true,
    disabled: false
  },
  messages: [],
  meta: {}
};

for (const variant of ["main domain", "custom-domain org"] as const) {
  const isCustom = variant === "custom-domain org";

  test.describe(`passkey settings — ${variant}`, () => {
    test("lists passkeys with names and dates; one remove disabled", async ({
      page
    }) => {
      const stopCapture = expectNoBrowserKratosRequest(page);
      await stubPostAuthLanding(page);
      await mockApi(page, [
        ...createAuthFlowHandlers({
          type: "settings",
          customDomainOrg: isCustom,
          withPasskeys: true
        }),
        ...createFallbackHandlers()
      ]);

      await page.goto("/security/passkeys?flow=flow-id-1", {
        waitUntil: "networkidle"
      });

      if (isCustom) {
        await expect(
          page.getByText(/Passkeys aren't available here/)
        ).toBeVisible();
        await expect(page.locator("button.passkey-btn")).toHaveCount(0);
        await expect(page.locator("button.passkey-remove-btn")).toHaveCount(0);
      } else {
        await expect(page.getByRole("heading", { name: "Passkeys" })).toBeVisible();
        await expect(page.locator(".passkey-row-name").first()).toHaveText(
          "MacBook Pro"
        );
        await expect(page.locator(".passkey-row")).toHaveCount(2);
        await expect(page.locator(".passkey-row-added").first()).toContainText(
          "2026"
        );
        const removeButtons = page.locator("button.passkey-remove-btn");
        await expect(removeButtons).toHaveCount(2);
        await expect(removeButtons.nth(0)).toBeEnabled();
        // The last remaining first-factor credential cannot be removed.
        await expect(removeButtons.nth(1)).toBeDisabled();
        await expect(page.locator("button.passkey-btn")).toHaveText(
          /Register passkey/
        );
      }

      // No password fields anywhere on this page, on either variant.
      await expect(page.locator("input[name='password']")).toHaveCount(0);
      await expect(page.getByText("Reset Password")).toHaveCount(0);

      stopCapture();
    });
  });
}

test.describe("passkey settings — canonical host actions", () => {
  test("remove re-renders the list in place instead of landing on the profile", async ({
    page
  }) => {
    const stopCapture = expectNoBrowserKratosRequest(page);
    const submitLog: SubmitLogEntry[] = [];
    let submitted = false;

    // Hand-rolled route (like email-login.spec.ts's error case): the
    // submit 303s to the settings return URL (…/account/profile), and
    // the flow Kratos then serves no longer lists the removed passkey.
    // The page must stay on the list and re-render it (spec §5.6
    // option b), not follow the profile landing.
    await stubPostAuthLanding(page);
    await mockApi(page, createFallbackHandlers());
    await page.route("**/api/auth/flow**", async route => {
      const url = new URL(route.request().url());
      if (url.pathname === "/api/auth/flow" && route.request().method() === "GET") {
        const body = submitted
          ? mockAuthFlowResponse({
              type: "settings",
              flowId: "flow-id-1",
              nodes: [
                csrfNode,
                ...passkeySettingsNodes().filter(
                  n =>
                    !(
                      n.attributes.name === "passkey_remove" &&
                      n.attributes.value === "a1b2c3d4e5f6"
                    )
                )
              ]
            })
          : mockAuthFlowResponse({
              type: "settings",
              flowId: "flow-id-1",
              withPasskeys: true
            });
        return route.fulfill({
          status: 200,
          contentType: "application/json",
          body: JSON.stringify(body)
        });
      }
      if (
        url.pathname === "/api/auth/flow/submit" &&
        route.request().method() === "POST"
      ) {
        submitLog.push({
          url: route.request().url(),
          method: route.request().method(),
          postData: route.request().postData(),
          headers: route.request().headers()
        });
        submitted = true;
        return route.fulfill({
          status: 303,
          contentType: "text/html",
          headers: { Location: "/account/profile" },
          body: ""
        });
      }
      return route.fulfill({ status: 404, body: "" });
    });

    await page.goto("/security/passkeys?flow=flow-id-1", {
      waitUntil: "networkidle"
    });

    await page.locator("button.passkey-remove-btn").first().click();

    // Still on the passkey list — not on /account/profile — with the
    // removed credential gone from the re-rendered list.
    await expect(page).toHaveURL(/\/security\/passkeys\?flow=flow-id-1$/);
    await expect(page.locator(".passkey-row")).toHaveCount(1);
    await expect(page.locator(".passkey-row-name")).toHaveText("iPhone");
    await expect(page.getByText("MacBook Pro")).toHaveCount(0);

    expect(submitLog).toHaveLength(1);
    const body = submitLog[0].postData ?? "";
    expect(body).toContain("method=passkey");
    expect(submitBodyParam(body, "passkey_remove")).toBe("a1b2c3d4e5f6");
    expect(body).toContain("csrf_token=test-csrf-token");
    expect(submitLog[0].url).toMatch(
      /\/api\/auth\/flow\/submit\?type=settings&id=flow-id-1$/
    );

    stopCapture();
  });

  test("a failed remove stays on the passkey list with the error", async ({
    page
  }) => {
    const stopCapture = expectNoBrowserKratosRequest(page);
    const submitLog: SubmitLogEntry[] = [];
    const errorMessage = "The passkey could not be removed.";

    await stubPostAuthLanding(page);
    await mockApi(page, [
      ...createAuthFlowHandlers({
        type: "settings",
        withPasskeys: true,
        submitLog,
        submitErrorFlow: mockAuthFlowResponse({
          type: "settings",
          withPasskeys: true,
          messages: [{ id: 4000001, text: errorMessage, type: "error" }]
        }),
        // Kratos's settings ui_url is /reset, not this page.
        submitErrorPath: "reset"
      }),
      ...createFallbackHandlers()
    ]);

    await page.goto("/security/passkeys?flow=flow-id-1", {
      waitUntil: "networkidle"
    });

    await page.locator("button.passkey-remove-btn").first().click();

    // Still on the passkey list — not bounced to /reset — with the
    // flow's error message rendered in place.
    await expect(page).toHaveURL(/\/security\/passkeys\?flow=flow-id-1$/);
    await expect(page.getByText(errorMessage)).toBeVisible();
    expect(submitLog).toHaveLength(1);

    stopCapture();
  });

  test("add-a-passkey re-renders the list in place with the new credential", async ({
    page
  }) => {
    const stopCapture = expectNoBrowserKratosRequest(page);
    const submitLog: SubmitLogEntry[] = [];
    let submitted = false;

    await page.addInitScript(stubCreate());
    await stubPostAuthLanding(page);
    await mockApi(page, createFallbackHandlers());
    await page.route("**/api/auth/flow**", async route => {
      const url = new URL(route.request().url());
      if (url.pathname === "/api/auth/flow" && route.request().method() === "GET") {
        const body = submitted
          ? mockAuthFlowResponse({
              type: "settings",
              flowId: "flow-id-1",
              nodes: [
                csrfNode,
                ...passkeySettingsNodes(),
                passkeyRemoveNode(
                  "Security Key",
                  "2026-11-19T10:00:00Z",
                  "beefcafe1234",
                  false
                )
              ]
            })
          : mockAuthFlowResponse({
              type: "settings",
              flowId: "flow-id-1",
              withPasskeys: true
            });
        return route.fulfill({
          status: 200,
          contentType: "application/json",
          body: JSON.stringify(body)
        });
      }
      if (
        url.pathname === "/api/auth/flow/submit" &&
        route.request().method() === "POST"
      ) {
        submitLog.push({
          url: route.request().url(),
          method: route.request().method(),
          postData: route.request().postData(),
          headers: route.request().headers()
        });
        submitted = true;
        return route.fulfill({
          status: 303,
          contentType: "text/html",
          headers: { Location: "/account/profile" },
          body: ""
        });
      }
      return route.fulfill({ status: 404, body: "" });
    });

    await page.goto("/security/passkeys?flow=flow-id-1", {
      waitUntil: "networkidle"
    });

    await page.locator("button.passkey-btn").click();

    // Still on the passkey list — not on /account/profile — with the
    // new credential in the re-rendered list.
    await expect(page).toHaveURL(/\/security\/passkeys\?flow=flow-id-1$/);
    await expect(page.locator(".passkey-row")).toHaveCount(3);
    await expect(page.getByText("Security Key")).toBeVisible();

    expect(submitLog).toHaveLength(1);
    const body = submitLog[0].postData ?? "";
    expect(body).toContain("method=passkey");
    const credential = JSON.parse(
      submitBodyParam(body, "passkey_settings_register") ?? "null"
    ) as Record<string, unknown>;
    expect(credential.id).toBe("test-credential-id");
    expect((credential.response as Record<string, unknown>).attestationObject).toBe(
      "BgcI"
    );
    expect(body).toContain("csrf_token=test-csrf-token");

    stopCapture();
  });

  test("a privileged-session error renders the re-auth message", async ({
    page
  }) => {
    const stopCapture = expectNoBrowserKratosRequest(page);
    await stubPostAuthLanding(page);
    await mockApi(page, [
      ...createAuthFlowHandlers({
        type: "settings",
        withPasskeys: true,
        messages: [
          {
            id: 4010001,
            text: "Please sign in again to continue.",
            type: "error"
          }
        ]
      }),
      ...createFallbackHandlers()
    ]);

    await page.goto("/security/passkeys?flow=flow-id-1", {
      waitUntil: "networkidle"
    });

    await expect(
      page.getByText("Please sign in again to continue.")
    ).toBeVisible();

    stopCapture();
  });
});
