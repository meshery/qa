/**
 * End-to-end coverage of the Security → Credentials create / edit form.
 *
 * The form is rendered from a canonical `@meshery/schemas` credential RJSF
 * schema (`{Prometheus,Grafana,Kubernetes}CredentialRjsfSchemaV1Beta1`), whose
 * properties are `name` and `secret`. `RJSFWrapper` does no remapping, so the
 * names the page writes into the formData and the names it reads back out are
 * joined to the schema by string keys alone.
 *
 * That is meshery-cloud#5918, wrong in both directions at once:
 *
 *   - POPULATE spread the stored secret blob flat and tacked `type` on
 *     (`{...rowData[3], type: rowData[2]}`). For a Kubernetes credential that
 *     is `{auth, cluster, type}` — no schema property among them — so RJSF
 *     dropped every key and the edit form opened BLANK. Against production that
 *     is 37,292 of 37,302 live rows.
 *   - SUBMIT posted `secret: formData`, the whole payload, so every save wrote
 *     the secret one level too deep with the credential's name duplicated
 *     inside it: `{credentialName, secret: {prometheusURL}}`.
 *
 * Both are asserted here where a user meets them: the fields that render with
 * the row's values, and the exact bytes that reach `POST`/`PUT
 * /api/integrations/credentials`.
 */

import { expect, test, type Page } from "@playwright/test";
import path from "node:path";
import {
  createAuthenticatedShellHandlers,
  createFallbackHandlers,
  createPermissionKeysHandler,
  createSharedShellHandlers,
  mockApi
} from "./helpers/network";

const EVIDENCE_DIR =
  process.env.CREDENTIAL_FORM_EVIDENCE_DIR ??
  path.resolve(__dirname, "..", "test-results", "credential-form-evidence");

const shot = (name: string) => path.join(EVIDENCE_DIR, `${name}.png`);

const authenticatedUser = {
  id: "user-1",
  first_name: "Test",
  last_name: "User",
  email: "test@example.com",
  preferences: { selectedOrg: "org-1" }
};

const organization = {
  id: "org-1",
  name: "Test Organization",
  // Derived so a free-port run does not bounce to /auth/switch-domain.
  domain: new URL(process.env.PLAYWRIGHT_BASE_URL || "http://localhost:3000").host
};

const credentialPermissions = [
  "VIEW_CREDENTIALS",
  "CREATE_CREDENTIAL",
  "EDIT_CREDENTIAL"
] as const;

/**
 * A Prometheus credential in the LEGACY double-nested shape this page used to
 * write — the only shape whose edit form ever populated, and then only by
 * accident. 8 such rows are live in production.
 */
const legacyPrometheusCredential = {
  id: "c0000000-0000-4000-8000-000000000001",
  name: "prod prometheus",
  userId: "user-1",
  type: "prometheus",
  secret: {
    credentialName: "prod prometheus",
    secret: { prometheusURL: "https://prom.example" }
  },
  createdAt: "2026-01-01T00:00:00Z",
  updatedAt: "2026-01-01T00:00:00Z"
};

type RecordedRequest = {
  method: string;
  body: Record<string, unknown>;
};

async function openCredentials(page: Page, credentials: Array<Record<string, unknown>>) {
  const mutations: RecordedRequest[] = [];

  await mockApi(page, [
    ...createSharedShellHandlers({
      user: authenticatedUser,
      organizations: [organization]
    }),
    ...createPermissionKeysHandler([...credentialPermissions]),
    ...createAuthenticatedShellHandlers({ orgId: "org-1", skipKeys: true }),
    request => {
      const method = request.method();
      const pathname = new URL(request.url()).pathname;

      if (pathname === "/api/integrations/credentials") {
        if (method === "GET") {
          return {
            status: 200,
            contentType: "application/json",
            body: {
              credentials,
              page: 0,
              pageSize: 10,
              totalCount: credentials.length
            }
          };
        }
        if (method === "POST" || method === "PUT") {
          mutations.push({
            method,
            body: JSON.parse(request.postData() ?? "{}") as Record<string, unknown>
          });
          return { status: 200, contentType: "application/json", body: {} };
        }
      }

      return undefined;
    },
    ...createFallbackHandlers()
  ]);

  await page.goto("/security/credentials", { waitUntil: "domcontentloaded" });

  return mutations;
}

/**
 * `RJSFWrapper` propagates form state to its parent through a 300 ms DEBOUNCED
 * effect (`ui/components/general/rjsf/index.tsx`), so the page's `formData` /
 * `credentialName` state trails the rendered fields. A submit inside that
 * window posts the PREVIOUS value — which is a real defect for a fast user, not
 * a test artifact, and is filed separately as meshery-cloud#5930. Wait it out
 * here rather than racing it, so this spec fails for shape reasons only.
 */
const waitForFormDebounce = (page: Page) => page.waitForTimeout(500);

/** Waits for the code-split RJSF chunk to render a real field, not the spinner. */
async function waitForForm(modal: ReturnType<Page["getByRole"]>) {
  await expect(
    modal.getByRole("textbox", { name: "Credential Name", exact: true })
  ).toBeVisible();
}

test.describe("credentials create/edit — the secret object is the payload", () => {
  test("create posts the secret object itself, with no extra nesting and no name inside it", async ({
    page
  }) => {
    const mutations = await openCredentials(page, []);

    await page.getByRole("button", { name: /^create$/i }).click();

    const modal = page.getByRole("dialog").filter({ hasText: "Generate Credential" });
    await expect(modal).toBeVisible();
    await waitForForm(modal);

    await modal
      .getByRole("textbox", { name: "Credential Name", exact: true })
      .fill("prod prometheus");
    await modal
      .getByRole("textbox", { name: "URL", exact: true })
      .fill("https://prom.example");
    await modal.screenshot({ path: shot("create-modal-filled") });

    await waitForFormDebounce(page);
    await modal.getByRole("button", { name: "Continue", exact: true }).click();

    await expect.poll(() => mutations.length).toBe(1);
    expect(mutations[0].method).toBe("POST");
    expect(mutations[0].body).toEqual({
      name: "prod prometheus",
      type: "prometheus",
      // NOT `{credentialName, secret: {...}}`. The canonical schema says the
      // form's `secret` object IS the persisted value.
      secret: { prometheusURL: "https://prom.example" }
    });
    // Stated separately because it is the user-visible harm: the credential's
    // name was being duplicated inside its own secret blob.
    expect(JSON.stringify(mutations[0].body.secret)).not.toContain("credentialName");
  });

  test("edit prefills a legacy double-nested row with the real secret, and saves it canonically", async ({
    page
  }) => {
    const mutations = await openCredentials(page, [legacyPrometheusCredential]);

    await expect(page.getByText("prod prometheus").first()).toBeVisible();

    // `L5EditIcon` renders a Sistent IconButton with a default aria-label, so
    // the row action is reachable by role without adding a test-only hook (its
    // React `key` is not a selector, and its `dataTestId` prop is opt-in).
    await page.getByRole("button", { name: "Edit" }).first().click();

    const modal = page.getByRole("dialog").filter({ hasText: "Update Credential" });
    await expect(modal).toBeVisible();
    await waitForForm(modal);

    // The populate direction. This form opened completely blank.
    await expect(
      modal.getByRole("textbox", { name: "Credential Name", exact: true })
    ).toHaveValue("prod prometheus");
    await expect(modal.getByRole("textbox", { name: "URL", exact: true })).toHaveValue(
      "https://prom.example"
    );
    await modal.screenshot({ path: shot("edit-modal-prefilled") });

    await modal
      .getByRole("textbox", { name: "URL", exact: true })
      .fill("https://prom2.example");
    await waitForFormDebounce(page);
    await modal.getByRole("button", { name: "Continue", exact: true }).click();

    await expect.poll(() => mutations.length).toBe(1);
    expect(mutations[0].method).toBe("PUT");
    expect(mutations[0].body).toEqual({
      id: legacyPrometheusCredential.id,
      name: "prod prometheus",
      type: "prometheus",
      secret: { prometheusURL: "https://prom2.example" }
    });
  });
});
