import { expect, test, type Page } from "@playwright/test";
import {
  createAuthFlowHandlers,
  expectNoBrowserKratosRequest,
  mockAuthFlowResponse,
  type AuthFlowNode,
  type SubmitLogEntry
} from "../helpers/auth-flow";
import { createFallbackHandlers, mockApi } from "../helpers/network";

// The shorter sign-up (#6247, #6248), end to end through the React pages:
//
//   1. One screen: name, email and password together, one submit.
//   2. Signed in at once: the registration lands on /registered in its
//      signed-in state (HandleRegistered adds ?signed_in=1 when the session
//      hook's session is present and the address is unverified).
//   3. Auto-verify: the emailed link opens /verification with the code
//      pre-filled (Kratos's link handler does that), and the page submits it
//      itself, through the code method, never the resend button.
//   4. Return to origin: a passed verification follows the flow's continue
//      link (/verified?return_to=...) on the current host.
//   5. Social sign-up: the provider's verified address arrives verified, so
//      the registration skips "check your email" and lands in the product.
//
// Node shapes below are the ones Kratos v25.4.0 returns (captured from a real
// Kratos run against install/environment/development/kratos.yml).

const VERIFY_FLOW = "verify-flow-1";
const CODE = "482913";

const csrf = (group = "default"): AuthFlowNode => ({
  type: "input",
  group,
  attributes: {
    name: "csrf_token",
    type: "hidden",
    value: "csrf",
    required: true,
    disabled: false
  },
  messages: [],
  meta: {}
});

// The verification flow after the email link was opened: code pre-filled.
const sentEmailNodes = (code: string): AuthFlowNode[] => [
  {
    type: "input",
    group: "code",
    attributes: {
      name: "method",
      type: "hidden",
      value: "code",
      required: false,
      disabled: false
    },
    messages: [],
    meta: {}
  },
  {
    type: "input",
    group: "code",
    attributes: {
      name: "code",
      type: "text",
      value: code,
      required: true,
      disabled: false
    },
    messages: [],
    meta: { label: { id: 1070012, text: "Verification code", type: "info" } }
  },
  {
    type: "input",
    group: "code",
    attributes: {
      name: "method",
      type: "submit",
      value: "code",
      required: false,
      disabled: false
    },
    messages: [],
    meta: { label: { id: 1070009, text: "Continue", type: "info" } }
  },
  csrf(),
  {
    type: "input",
    group: "code",
    attributes: {
      name: "email",
      type: "submit",
      value: "ada@example.com",
      required: false,
      disabled: false
    },
    messages: [],
    meta: { label: { id: 1070007, text: "Resend code", type: "info" } }
  }
];

const stubVerifiedLanding = async (page: Page) => {
  await page.route("**/verified**", route =>
    route.fulfill({
      status: 200,
      contentType: "text/html",
      body: `<!doctype html><html><body><main data-testid="verified-landing">verified</main></body></html>`
    })
  );
};

test.describe("shorter sign-up", () => {
  test("one screen, then signed in on the check-email page", async ({ page }) => {
    const stopCapture = expectNoBrowserKratosRequest(page);
    const submitLog: SubmitLogEntry[] = [];
    await mockApi(page, [
      ...createAuthFlowHandlers({
        type: "registration",
        submitLog,
        submitSuccessLocation: "/registered?signed_in=1"
      }),
      ...createFallbackHandlers()
    ]);

    await page.goto("/registration?flow=flow-id-1", { waitUntil: "networkidle" });

    // Everything on one screen: no profile step before the password.
    const first = page.locator("input[name='traits.name.first_name']");
    const last = page.locator("input[name='traits.name.last_name']");
    const email = page.locator("input[name='traits.email']");
    const password = page.locator("input[name='password']");
    for (const field of [first, last, email, password]) await expect(field).toBeVisible();
    await expect(page.locator("button#submit")).toHaveCount(1);

    await first.fill("Ada");
    await last.fill("Lovelace");
    await email.fill("ada@example.com");
    await password.fill("strong-password-123");
    await page.locator("button#submit").click();

    await page.waitForURL("**/registered?signed_in=1");
    expect(submitLog).toHaveLength(1);
    expect(submitLog[0].postData).toContain("method=password");

    await expect(page.getByRole("heading", { name: "Check your email" })).toBeVisible();
    await expect(page.getByTestId("registered-sent-to")).toContainText(
      "You're signed in. Open the link to verify your email, and we'll take you back to where you started."
    );
    await expect(page.getByTestId("registered-change-email")).toHaveText(
      "Sign out and use a different email"
    );
    await expect(page.getByTestId("registered-change-email")).toHaveAttribute(
      "href",
      "/logout"
    );

    stopCapture();
  });

  test("the email link verifies on its own and returns to the origin", async ({
    page
  }) => {
    const stopCapture = expectNoBrowserKratosRequest(page);
    const submitLog: SubmitLogEntry[] = [];
    await stubVerifiedLanding(page);
    await mockApi(page, [
      ...createAuthFlowHandlers({
        type: "verification",
        flowId: VERIFY_FLOW,
        state: "sent_email",
        nodes: sentEmailNodes(CODE),
        submitLog,
        // The flow Kratos serves once the code is accepted (the helper serves
        // it after the submit's 303 back to the flow page).
        submitErrorFlow: mockAuthFlowResponse({
          type: "verification",
          flowId: VERIFY_FLOW,
          state: "passed_challenge",
          nodes: [csrf()],
          continueTo: "/verified?return_to=%2Fcatalog%3Fx%3D1"
        })
      }),
      ...createFallbackHandlers()
    ]);

    await page.goto(`/verification?flow=${VERIFY_FLOW}`);

    await page.waitForURL("**/verified?return_to=%2Fcatalog%3Fx%3D1");
    await expect(page.getByTestId("verified-landing")).toBeVisible();

    expect(submitLog).toHaveLength(1);
    const body = submitLog[0].postData ?? "";
    expect(body).toContain(`code=${CODE}`);
    expect(body).toContain("method=code");
    expect(body).not.toContain("email=");
    expect(submitLog[0].url).toMatch(
      new RegExp(`/api/auth/flow/submit\\?type=verification&id=${VERIFY_FLOW}$`)
    );

    stopCapture();
  });

  test("a rejected code is shown, not resubmitted", async ({ page }) => {
    const submitLog: SubmitLogEntry[] = [];
    await mockApi(page, [
      ...createAuthFlowHandlers({
        type: "verification",
        flowId: VERIFY_FLOW,
        state: "sent_email",
        nodes: sentEmailNodes(CODE),
        messages: [
          {
            id: 4070006,
            text: "The verification code is invalid or has already been used.",
            type: "error"
          }
        ],
        submitLog
      }),
      ...createFallbackHandlers()
    ]);

    await page.goto(`/verification?flow=${VERIFY_FLOW}`, { waitUntil: "networkidle" });
    await expect(page.getByText(/invalid or has already been used/)).toBeVisible();
    await expect(page.locator("input[name='code']")).toBeVisible();
    expect(submitLog).toHaveLength(0);
  });

  test("a social sign-up arrives verified and lands in the product", async ({ page }) => {
    const submitLog: SubmitLogEntry[] = [];
    // Kratos lands the OIDC registration on /registered; the identity's
    // address is verified (the claim mapper's verified_addresses), so
    // HandleRegistered sends it straight on to the dashboard rather than
    // "check your email". The fixture collapses that server hop into the
    // submit's landing; the server half is pinned by
    // TestHandleRegistered_SignedInVerifiedGoesToDashboard and the mapper
    // drift test in install/environment.
    await mockApi(page, [
      ...createAuthFlowHandlers({
        type: "registration",
        submitLog,
        submitSuccessLocation: "/dashboard"
      }),
      ...createFallbackHandlers()
    ]);

    await page.goto("/registration?flow=flow-id-1", { waitUntil: "networkidle" });
    await page.getByRole("button", { name: /sign up with github/i }).click();

    await page.waitForURL("**/dashboard");
    expect(page.url()).not.toContain("/registered");
    expect(submitLog).toHaveLength(1);
    expect(submitLog[0].postData).toContain("provider=github");
  });

  // A visitor signing up on a tenant host sees that organization's brand,
  // never the Provider's (#6248 follows the tenant-branding requirement).
  test("tenant host: verification and check-email pages carry no Layer5 or Meshery text", async ({
    page
  }) => {
    await mockApi(page, [
      ...createAuthFlowHandlers({
        type: "verification",
        flowId: VERIFY_FLOW,
        state: "sent_email",
        nodes: sentEmailNodes(CODE),
        customDomainOrg: true,
        messages: [
          { id: 4070006, text: "The verification code is invalid.", type: "error" }
        ]
      }),
      ...createFallbackHandlers()
    ]);

    await page.goto(`/verification?flow=${VERIFY_FLOW}`, { waitUntil: "networkidle" });
    await expect(page.locator("input[name='code']")).toBeVisible();
    await expect(page.locator("body")).not.toContainText(/layer5|meshery/i);

    await page.goto("/registered?signed_in=1", { waitUntil: "networkidle" });
    await expect(page.getByRole("heading", { name: "Check your email" })).toBeVisible();
    await expect(page.locator("body")).not.toContainText(/layer5|meshery/i);
  });
});
