import { expect, test } from "@playwright/test";
import {
  createAuthFlowHandlers,
  expectNoBrowserKratosRequest,
  mockAuthFlowResponse,
  stubPostAuthLanding,
  type SubmitLogEntry
} from "../helpers/auth-flow";
import { createFallbackHandlers, mockApi } from "../helpers/network";

// passkey-login.spec.ts covers the WebAuthn passkey login path from the
// React page's perspective (issue #6478, spec §7.4 Tier A — mocked).
//
//   * canonical host: the "Sign in with passkey" button renders, the
//     identifier carries `autocomplete="username webauthn"`, and the
//     button + conditional-UI ceremonies submit `method=passkey` +
//     `passkey_login=<assertion JSON>` to /api/auth/flow/submit.
//   * custom-domain org (`passkeysAvailable: false`): no passkey button,
//     identifier autocomplete stays "username", password + OIDC
//     unchanged.
//
// `navigator.credentials` is stubbed per test (the real ceremony needs
// a platform authenticator — that is the live tier,
// passkey-live.spec.ts). Every test asserts the topology invariant: no
// browser→Kratos request, and the only auth POST target is the submit
// proxy.

const FAKE_ASSERTION = {
  id: "test-credential-id",
  rawId: [1, 2, 3],
  type: "public-key",
  response: {
    clientDataJSON: [4, 5],
    authenticatorData: [6, 7, 8],
    signature: [9],
    userHandle: [10, 11]
  }
};

const stubCredentials = (opts: {
  conditionalAvailable: boolean;
  get: "resolve" | "cancel" | "fail";
}) =>
  `
  const toBuffer = (bytes) => new Uint8Array(bytes).buffer;
  const fake = {
    id: ${JSON.stringify(FAKE_ASSERTION.id)},
    rawId: toBuffer(${JSON.stringify(FAKE_ASSERTION.rawId)}),
    type: "public-key",
    response: {
      clientDataJSON: toBuffer(${JSON.stringify(FAKE_ASSERTION.response.clientDataJSON)}),
      authenticatorData: toBuffer(${JSON.stringify(FAKE_ASSERTION.response.authenticatorData)}),
      signature: toBuffer(${JSON.stringify(FAKE_ASSERTION.response.signature)}),
      userHandle: toBuffer(${JSON.stringify(FAKE_ASSERTION.response.userHandle)})
    }
  };
  window.PublicKeyCredential = class {
    static async isConditionalMediationAvailable() {
      return ${opts.conditionalAvailable};
    }
  };
  Object.defineProperty(window.navigator, "credentials", {
    value: {
      get: async () => {
        ${opts.get === "resolve" ? "return fake;" : ""}
        ${opts.get === "cancel" ? 'throw new DOMException("The operation was cancelled.", "NotAllowedError");' : ""}
        ${opts.get === "fail" ? 'throw new DOMException("The operation is insecure.", "SecurityError");' : ""}
      },
      create: async () => { throw new DOMException("Not implemented.", "NotSupportedError"); }
    },
    configurable: true
  });
  `;

const submitBodyParam = (body: string, name: string) =>
  new URLSearchParams(body).get(name);

for (const variant of ["main domain", "custom-domain org"] as const) {
  const isCustom = variant === "custom-domain org";

  test.describe(`passkey login — ${variant}`, () => {
    test("renders the passkey button with conditional-UI autocomplete", async ({
      page
    }) => {
      const stopCapture = expectNoBrowserKratosRequest(page);
      await stubPostAuthLanding(page);
      await mockApi(page, [
        ...createAuthFlowHandlers({
          type: "login",
          customDomainOrg: isCustom,
          withPasskeys: true
        }),
        ...createFallbackHandlers()
      ]);

      await page.goto("/login?flow=flow-id-1", { waitUntil: "networkidle" });

      const passkeyButton = page.locator("button.passkey-btn");
      if (isCustom) {
        await expect(passkeyButton).toHaveCount(0);
        await expect(page.locator("input[name='identifier']")).toHaveAttribute(
          "autocomplete",
          "username"
        );
      } else {
        await expect(passkeyButton).toBeVisible();
        await expect(passkeyButton).toHaveText(/Sign in with passkey/);
        await expect(passkeyButton).toHaveAttribute("type", "button");
        await expect(page.locator("input[name='identifier']")).toHaveAttribute(
          "autocomplete",
          "username webauthn"
        );
      }

      // Password + OIDC are unchanged on both variants.
      await expect(page.locator("input[name='password']")).toBeVisible();
      await expect(page.locator("button#submit")).toBeVisible();
      await expect(
        page.locator("button.social-auth-btn.github")
      ).toBeVisible();

      stopCapture();
    });

    test("no passkey button without PublicKeyCredential", async ({ page }) => {
      test.skip(isCustom, "canonical host only");
      const stopCapture = expectNoBrowserKratosRequest(page);
      await page.addInitScript(() => {
        Object.defineProperty(window, "PublicKeyCredential", {
          value: undefined,
          configurable: true
        });
      });
      await stubPostAuthLanding(page);
      await mockApi(page, [
        ...createAuthFlowHandlers({
          type: "login",
          withPasskeys: true
        }),
        ...createFallbackHandlers()
      ]);

      await page.goto("/login?flow=flow-id-1", { waitUntil: "networkidle" });

      await expect(page.locator("button.passkey-btn")).toHaveCount(0);
      await expect(page.locator("button#submit")).toBeVisible();

      stopCapture();
    });
  });
}

test.describe("passkey login — canonical host ceremonies", () => {
  test("button path submits method=passkey with the assertion JSON", async ({
    page
  }) => {
    const stopCapture = expectNoBrowserKratosRequest(page);
    const submitLog: SubmitLogEntry[] = [];

    // Conditional mediation off, so only the button path can fire.
    await page.addInitScript(stubCredentials({ conditionalAvailable: false, get: "resolve" }));
    await stubPostAuthLanding(page);
    await mockApi(page, [
      ...createAuthFlowHandlers({
        type: "login",
        withPasskeys: true,
        submitLog,
        submitSuccessLocation: "/dashboard"
      }),
      ...createFallbackHandlers()
    ]);

    await page.goto("/login?flow=flow-id-1", { waitUntil: "networkidle" });

    await page.locator("button.passkey-btn").click();
    await page.waitForURL("**/dashboard");

    expect(submitLog).toHaveLength(1);
    const body = submitLog[0].postData ?? "";
    expect(body).toContain("method=passkey");
    const assertion = JSON.parse(submitBodyParam(body, "passkey_login") ?? "null") as Record<
      string,
      unknown
    >;
    expect(assertion.id).toBe("test-credential-id");
    expect(assertion.type).toBe("public-key");
    expect(assertion.rawId).toBe("AQID");
    const response = assertion.response as Record<string, unknown>;
    expect(response.clientDataJSON).toBe("BAU");
    expect(response.userHandle).toBe("Cgs");
    expect(body).toContain("csrf_token=test-csrf-token");
    expect(submitLog[0].url).toMatch(
      /\/api\/auth\/flow\/submit\?type=login&id=flow-id-1$/
    );

    stopCapture();
  });

  test("conditional UI submits on autofill selection", async ({ page }) => {
    const stopCapture = expectNoBrowserKratosRequest(page);
    const submitLog: SubmitLogEntry[] = [];

    await page.addInitScript(stubCredentials({ conditionalAvailable: true, get: "resolve" }));
    await stubPostAuthLanding(page);
    await mockApi(page, [
      ...createAuthFlowHandlers({
        type: "login",
        withPasskeys: true,
        submitLog,
        submitSuccessLocation: "/dashboard"
      }),
      ...createFallbackHandlers()
    ]);

    await page.goto("/login?flow=flow-id-1", { waitUntil: "networkidle" });

    // No click: the conditional-UI request fires on mount and the stubbed
    // selection submits.
    await page.waitForURL("**/dashboard");

    expect(submitLog).toHaveLength(1);
    const body = submitLog[0].postData ?? "";
    expect(body).toContain("method=passkey");
    expect(submitBodyParam(body, "passkey_login")).toContain("test-credential-id");

    stopCapture();
  });

  test("a cancelled ceremony stays on the form, silently", async ({ page }) => {
    const stopCapture = expectNoBrowserKratosRequest(page);
    const submitLog: SubmitLogEntry[] = [];

    await page.addInitScript(stubCredentials({ conditionalAvailable: false, get: "cancel" }));
    await stubPostAuthLanding(page);
    await mockApi(page, [
      ...createAuthFlowHandlers({
        type: "login",
        withPasskeys: true,
        submitLog,
        submitSuccessLocation: "/dashboard"
      }),
      ...createFallbackHandlers()
    ]);

    await page.goto("/login?flow=flow-id-1", { waitUntil: "networkidle" });

    await page.locator("button.passkey-btn").click();
    await page.waitForTimeout(500);

    expect(submitLog).toHaveLength(0);
    await expect(page).toHaveURL(/\/login\?flow=flow-id-1$/);
    // No inline error for a user cancel — the form stays usable.
    await expect(page.locator("input[name='identifier']")).toBeVisible();
    await expect(page.locator("input[name='password']")).toBeVisible();

    stopCapture();
  });

  test("a failed ceremony shows an inline message and never navigates to /error", async ({
    page
  }) => {
    const stopCapture = expectNoBrowserKratosRequest(page);
    const submitLog: SubmitLogEntry[] = [];

    await page.addInitScript(stubCredentials({ conditionalAvailable: false, get: "fail" }));
    await stubPostAuthLanding(page);
    await mockApi(page, [
      ...createAuthFlowHandlers({
        type: "login",
        withPasskeys: true,
        submitLog,
        submitSuccessLocation: "/dashboard"
      }),
      ...createFallbackHandlers()
    ]);

    await page.goto("/login?flow=flow-id-1", { waitUntil: "networkidle" });

    await page.locator("button.passkey-btn").click();
    await expect(page.getByText(/Passkeys aren't available on this site/)).toBeVisible();

    expect(submitLog).toHaveLength(0);
    await expect(page).toHaveURL(/\/login\?flow=flow-id-1$/);

    stopCapture();
  });

  test("a failed passkey submit re-renders the flow in place", async ({ page }) => {
    const stopCapture = expectNoBrowserKratosRequest(page);
    const submitLog: SubmitLogEntry[] = [];
    const freshFlowId = "flow-id-fresh";
    const errorMessage = "The provided credentials are invalid.";

    await page.addInitScript(stubCredentials({ conditionalAvailable: false, get: "resolve" }));
    await stubPostAuthLanding(page);
    await mockApi(page, createFallbackHandlers());
    await page.route("**/api/auth/flow**", async route => {
      const url = new URL(route.request().url());
      if (url.pathname === "/api/auth/flow" && route.request().method() === "GET") {
        const flowId = url.searchParams.get("id");
        const messages =
          flowId === freshFlowId
            ? [{ id: 4000006, text: errorMessage, type: "error" as const }]
            : [];
        return route.fulfill({
          status: 200,
          contentType: "application/json",
          body: JSON.stringify(
            mockAuthFlowResponse({
              type: "login",
              flowId: flowId ?? "flow-id-1",
              withPasskeys: true,
              messages
            })
          )
        });
      }
      if (
        url.pathname === "/api/auth/flow/submit" &&
        route.request().method() === "POST"
      ) {
        if (submitLog) {
          submitLog.push({
            url: route.request().url(),
            method: route.request().method(),
            postData: route.request().postData(),
            headers: route.request().headers()
          });
        }
        return route.fulfill({
          status: 303,
          contentType: "text/html",
          headers: { Location: `/login?flow=${freshFlowId}` },
          body: ""
        });
      }
      return route.fulfill({ status: 404, body: "" });
    });

    await page.goto("/login?flow=flow-id-1", { waitUntil: "networkidle" });
    await page.locator("button.passkey-btn").click();

    await expect(page).toHaveURL(new RegExp(`/login\\?flow=${freshFlowId}$`));
    await expect(page.getByText(/provided credentials are invalid/i).first()).toBeVisible();
    expect(submitLog).toHaveLength(1);
    expect(submitLog[0].postData ?? "").toContain("method=passkey");

    stopCapture();
  });
});
