// Auth-flow Playwright helper. Mirrors the cloud-server proxy contract
// documented in docs/reference/authentication-and-identity.md so each spec can drive a realistic
// Browser → Cloud Server → Kratos chain without a live Kratos backend.
//
// The helper exposes:
//
//   * `mockAuthFlowResponse` — produces the canned flow JSON the
//     /api/auth/flow GET returns. Per flow type it ships the inputs the
//     legacy Kratos UI emits (csrf_token, identifier, password, method,
//     provider), so the React form renders the way the user sees it.
//
//   * `createAuthFlowHandlers` — bundles handlers for /api/auth/flow,
//     /api/auth/flow/init, /api/auth/flow/submit. The submit handler
//     captures every browser POST in a `submitLog` array tests can
//     inspect (headers, form body, query). On success it 303s to the
//     supplied `submitSuccessLocation`; on validation failure it 400s
//     with a refreshed flow that includes an error message.
//
//   * `customDomainOrg` — toggles the org payload to a
//     custom-domain-mapped org with branded carousel, FAQs, and theme
//     vars, so per-flow specs can run a "main domain" pass and a
//     "custom domain" pass through the same body.
//
//   * `expectNoBrowserKratosRequest` — architecture guard. Every spec
//     that drives an auth page asserts via page.on('request') that the
//     browser issued no request to a URL containing `kratos`, no
//     request to `/.ory/...`, and no POST to a URL outside
//     /api/auth/flow/submit. This is the test plan's Layer-D
//     "architecture-guards.spec.ts" requirement, applied per spec so
//     the guarantee is checked alongside the actual flow.

import type { Page, Request, Route } from "@playwright/test";

export type AuthFlowType =
  "login" | "registration" | "verification" | "recovery" | "settings";

export interface SubmitLogEntry {
  url: string;
  method: string;
  postData: string | null;
  headers: Record<string, string>;
}

export interface MockAuthFlowOptions {
  /** Flow type the React page is rendering. */
  type: AuthFlowType;
  /** Flow ID echoed back in the response. */
  flowId?: string;
  /** Replace the default node set (CSRF + identifier + password + OIDC). */
  nodes?: AuthFlowNode[];
  /** Flow-level messages (errors / confirmations). */
  messages?: AuthFlowMessage[];
  /** State for verification / recovery flows. */
  state?: "" | "sent_email" | "passed_challenge";
  /** Use a custom-domain-mapped org (carousel, FAQ, theme overrides). */
  customDomainOrg?: boolean;
  /** Override site key (registration captcha). Pass empty string for unset. */
  recaptchaSiteKey?: string;
  /** ProgramName cookie hint surfaced to the React page. */
  programName?: string;
  /**
   * The server-computed host gate (`OrgAuthData.passkeysAvailable`):
   * true on the canonical host, false on registered custom-domain hosts.
   * Defaults to `!customDomainOrg` — the server contract — so a spec
   * only names it when it is deliberately testing the other side.
   */
  passkeysAvailable?: boolean;
  /**
   * Append the per-type passkey nodes (§5.1) to the default node set:
   * login gets `passkey_challenge` + `passkey_login` + trigger,
   * registration gets `passkey_create_data` + `passkey_register` +
   * trigger, settings gets create data + `passkey_settings_register` +
   * trigger + two `passkey_remove` rows (one disabled). The factories
   * are exported for specs that need an exact node set instead.
   */
  withPasskeys?: boolean;
  /**
   * JSON-encoded spam filter configuration surfaced to the React page
   * via FlowConfig.spamFilter. Mirrors the wire format the cloud server
   * emits in server/handlers/auth_flow.go::buildFlowConfig — a stringified
   * JSON object with `blockedDomains` / `blockedNames` arrays. Specs that
   * exercise registration.tsx::validateRegistration's spam-filter branch
   * pass a stringified `{"blockedDomains":["spam.example"], …}` here.
   */
  spamFilter?: string;
  /**
   * Path and query of a passed verification's "continue" link. The cloud
   * server carries it as a node of type "a" (name "continue", type
   * "anchor"), #6248.
   */
  continueTo?: string;
}

export interface AuthFlowNode {
  type: string;
  group: string;
  attributes: {
    name: string;
    type: string;
    value: unknown;
    required: boolean;
    disabled: boolean;
  };
  messages: AuthFlowMessage[];
  meta: {
    label?: {
      id: number;
      text: string;
      type: string;
      /** Kratos label context, e.g. a passkey's displayName/addedAt. */
      context?: Record<string, unknown>;
    };
  };
}

export interface AuthFlowMessage {
  id: number;
  text: string;
  type: "info" | "error" | "success";
}

const CSRF_NODE: AuthFlowNode = {
  type: "input",
  group: "default",
  attributes: {
    name: "csrf_token",
    type: "hidden",
    value: "test-csrf-token",
    required: true,
    disabled: false
  },
  messages: [],
  meta: {}
};

const IDENTIFIER_NODE: AuthFlowNode = {
  type: "input",
  group: "default",
  attributes: {
    name: "identifier",
    type: "email",
    value: "",
    required: true,
    disabled: false
  },
  messages: [],
  meta: { label: { id: 1070002, text: "E-Mail", type: "info" } }
};

const PASSWORD_NODE: AuthFlowNode = {
  type: "input",
  group: "default",
  attributes: {
    name: "password",
    type: "password",
    value: "",
    required: true,
    disabled: false
  },
  messages: [],
  meta: { label: { id: 1070001, text: "Password", type: "info" } }
};

const PASSWORD_SUBMIT_NODE = (label: string): AuthFlowNode => ({
  type: "input",
  group: "default",
  attributes: {
    name: "method",
    type: "submit",
    value: "password",
    required: false,
    disabled: false
  },
  messages: [],
  meta: { label: { id: 1019001, text: label, type: "info" } }
});

const OIDC_SUBMIT_NODE = (provider: string, label: string): AuthFlowNode => ({
  type: "input",
  group: "oidc",
  attributes: {
    name: "provider",
    type: "submit",
    value: provider,
    required: false,
    disabled: false
  },
  messages: [],
  meta: { label: { id: 1010010, text: label, type: "info" } }
});

const FIRST_NAME_NODE: AuthFlowNode = {
  type: "input",
  group: "default",
  attributes: {
    name: "traits.name.first_name",
    type: "text",
    value: "",
    required: true,
    disabled: false
  },
  messages: [],
  meta: { label: { id: 1070101, text: "First Name", type: "info" } }
};

const LAST_NAME_NODE: AuthFlowNode = {
  type: "input",
  group: "default",
  attributes: {
    name: "traits.name.last_name",
    type: "text",
    value: "",
    required: true,
    disabled: false
  },
  messages: [],
  meta: { label: { id: 1070102, text: "Last Name", type: "info" } }
};

const EMAIL_TRAIT_NODE: AuthFlowNode = {
  type: "input",
  group: "default",
  attributes: {
    name: "traits.email",
    type: "email",
    value: "",
    required: true,
    disabled: false
  },
  messages: [],
  meta: { label: { id: 1070103, text: "E-Mail", type: "info" } }
};

// EMAIL_NODE — `name="email"` (NOT `traits.email`). The legacy Kratos
// verification and recovery flows expose the email field under the
// flat `email` name. The traits-prefixed form is registration-specific.
// `verification.tsx` and `recovery.tsx` query for the flat field; using
// `traits.email` here would put them on the wrong code path.
const EMAIL_NODE = (group: string): AuthFlowNode => ({
  type: "input",
  group,
  attributes: {
    name: "email",
    type: "email",
    value: "",
    required: true,
    disabled: false
  },
  messages: [],
  meta: { label: { id: 1070007, text: "Email", type: "info" } }
});

// Settings-flow nodes use `group: 'password'` so password-reset.tsx's
// `<KratosForm filterGroups={["password"]} />` lets them through.
// Real Kratos emits the password-method nodes under that group; the
// settings page's password-reset variant filters to it specifically.
const settingsPasswordNode = (): AuthFlowNode => ({
  ...PASSWORD_NODE,
  group: "password"
});

const settingsPasswordSubmit = (label: string): AuthFlowNode => ({
  ...PASSWORD_SUBMIT_NODE(label),
  group: "password"
});

// ---------------------------------------------------------------------------
// Passkey nodes (spec §5.1 — Kratos v26.2.0 shapes)
//
// Label ids are 0 here: Kratos's passkey label ids are not pinned by this
// suite, and assertions key off the label text. The challenge /
// create-data JSON uses localhost RP values (the mocked pages run on
// http://localhost:3000, a secure context for WebAuthn).
// ---------------------------------------------------------------------------

const PASSKEY_CHALLENGE_JSON = JSON.stringify({
  publicKey: {
    // base64url of bytes 0..31.
    challenge: "AAECAwQFBgcICQoLDA0ODxAREhMUFRYXGBkaGxwdHh8",
    rpId: "localhost",
    allowCredentials: [],
    userVerification: "required",
    timeout: 60000
  }
});

const passkeyPublicKeyOptions = (userName: string) => ({
  challenge: "AAECAwQFBgcICQoLDA0ODxAREhMUFRYXGBkaGxwdHh8",
  rp: { id: "localhost", name: "Layer5 Cloud" },
  user: {
    // base64url of 32 zero bytes.
    id: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
    name: userName,
    displayName: userName
  },
  pubKeyCredParams: [
    { type: "public-key", alg: -7 },
    { type: "public-key", alg: -257 }
  ],
  authenticatorSelection: { userVerification: "required", residentKey: "required" },
  timeout: 60000,
  attestation: "none"
});

// Registration wraps the creation options (passkeyCreateData:
// credentialOptions + displayNameFieldName); settings carries the bare
// CredentialCreation. Both shapes must parse — see
// utility/passkey.ts::parsePasskeyCreateData.
const passkeyCreateDataNode = (shape: "registration" | "settings"): AuthFlowNode => ({
  type: "input",
  group: "passkey",
  attributes: {
    name: "passkey_create_data",
    type: "hidden",
    value:
      shape === "registration"
        ? JSON.stringify({
            credentialOptions: { publicKey: passkeyPublicKeyOptions("") },
            displayNameFieldName: "traits.email"
          })
        : JSON.stringify({ publicKey: passkeyPublicKeyOptions("test-user@layer5.io") }),
    required: false,
    disabled: false
  },
  messages: [],
  meta: {}
});

const passkeyHiddenFieldNode = (name: string): AuthFlowNode => ({
  type: "input",
  group: "passkey",
  attributes: {
    name,
    type: "hidden",
    value: "",
    required: false,
    disabled: false
  },
  messages: [],
  meta: {}
});

const passkeyTriggerNode = (name: string, label: string): AuthFlowNode => ({
  type: "input",
  group: "passkey",
  attributes: {
    name,
    type: "button",
    value: "",
    required: false,
    disabled: false
  },
  messages: [],
  meta: { label: { id: 0, text: label, type: "info" } }
});

export const passkeyRemoveNode = (
  displayName: string,
  addedAt: string,
  hexId: string,
  disabled: boolean
): AuthFlowNode => ({
  type: "input",
  group: "passkey",
  attributes: {
    name: "passkey_remove",
    type: "submit",
    value: hexId,
    required: false,
    disabled
  },
  messages: [],
  meta: {
    label: {
      id: 0,
      text: "Remove passkey",
      type: "info",
      context: { displayName, addedAt }
    }
  }
});

/** Login flow passkey nodes: challenge + submit field + trigger. */
export function passkeyLoginNodes(): AuthFlowNode[] {
  return [
    {
      type: "input",
      group: "passkey",
      attributes: {
        name: "passkey_challenge",
        type: "hidden",
        value: PASSKEY_CHALLENGE_JSON,
        required: false,
        disabled: false
      },
      messages: [],
      meta: {}
    },
    passkeyHiddenFieldNode("passkey_login"),
    passkeyTriggerNode("passkey_login_trigger", "Sign in with passkey")
  ];
}

/** Registration flow passkey nodes: create data + submit field + trigger. */
export function passkeyRegistrationNodes(): AuthFlowNode[] {
  return [
    passkeyCreateDataNode("registration"),
    passkeyHiddenFieldNode("passkey_register"),
    passkeyTriggerNode("passkey_register_trigger", "Register a passkey")
  ];
}

/**
 * Settings flow passkey nodes: create data + submit field + trigger +
 * two remove rows — the second disabled, as Kratos does when it is the
 * last remaining first-factor credential.
 */
export function passkeySettingsNodes(): AuthFlowNode[] {
  return [
    passkeyCreateDataNode("settings"),
    passkeyHiddenFieldNode("passkey_settings_register"),
    passkeyTriggerNode("passkey_register_trigger", "Register passkey"),
    passkeyRemoveNode("MacBook Pro", "2026-11-10T08:00:00Z", "a1b2c3d4e5f6", false),
    passkeyRemoveNode("iPhone", "2026-11-12T09:30:00Z", "0f1e2d3c4b5a", true)
  ];
}

const passkeyNodesForFlow = (type: AuthFlowType): AuthFlowNode[] => {
  switch (type) {
    case "login":
      return passkeyLoginNodes();
    case "registration":
      return passkeyRegistrationNodes();
    case "settings":
      return passkeySettingsNodes();
    default:
      return [];
  }
};

const defaultNodesForFlow = (type: AuthFlowType): AuthFlowNode[] => {
  switch (type) {
    case "login":
      return [
        CSRF_NODE,
        IDENTIFIER_NODE,
        PASSWORD_NODE,
        PASSWORD_SUBMIT_NODE("Sign in"),
        OIDC_SUBMIT_NODE("github", "Sign in with GitHub"),
        OIDC_SUBMIT_NODE("google", "Sign in with Google")
      ];
    case "registration":
      return [
        CSRF_NODE,
        FIRST_NAME_NODE,
        LAST_NAME_NODE,
        EMAIL_TRAIT_NODE,
        PASSWORD_NODE,
        PASSWORD_SUBMIT_NODE("Sign up"),
        OIDC_SUBMIT_NODE("github", "Sign up with GitHub"),
        OIDC_SUBMIT_NODE("google", "Sign up with Google")
      ];
    case "verification":
      // Real Kratos verification nodes: csrf_token + email (flat,
      // group="code"); the React page reads `email`, not
      // `traits.email`.
      return [
        CSRF_NODE,
        EMAIL_NODE("code"),
        { ...PASSWORD_SUBMIT_NODE("Resend verification"), group: "code" }
      ];
    case "recovery":
      // Real Kratos recovery nodes: csrf_token + email (flat,
      // group="code"). Same shape as verification.
      return [
        CSRF_NODE,
        EMAIL_NODE("code"),
        { ...PASSWORD_SUBMIT_NODE("Send recovery code"), group: "code" }
      ];
    case "settings":
      // Settings (password-reset variant) nodes use group="password"
      // so password-reset.tsx's filterGroups=["password"] keeps them.
      // CSRF lives in the password group too — Kratos emits a CSRF
      // node per group on settings flows.
      return [
        { ...CSRF_NODE, group: "password" },
        settingsPasswordNode(),
        settingsPasswordSubmit("Reset Password")
      ];
  }
};

// Custom-domain org payload mirrors what server/handlers/auth_flow.go's
// buildOrgAuthData returns for an org mapped via OrganizationDAO::
// GetOrganizationByDomain. Theme + branding overrides live in
// org.metadata.preferences.AuthBranding on the server; the JSON-wire
// shape arrives at the React page under `org.authBranding`.
const customDomainOrgPayload = {
  id: "11111111-2222-3333-4444-555555555555",
  name: "Acme Engineering",
  theme: {
    id: "acme",
    logo: {
      desktop: "https://cdn.acme.example/logo.svg",
      mobile: "https://cdn.acme.example/logo-m.svg",
      darkDesktop: "https://cdn.acme.example/logo-dark.svg"
    },
    vars: {
      prominent: "#7a3aff",
      hover: "#9b5fff",
      default: "#2b1a5b",
      secondaryBar: "#e5dcff"
    }
  },
  authBranding: {
    carousel: [
      {
        imageUrl: "https://cdn.acme.example/slide-1.png",
        title: "Acme Workbench",
        description: "Build, ship, and observe your service mesh."
      },
      {
        imageUrl: "https://cdn.acme.example/slide-2.png",
        title: "Cloud-native automation",
        description: "Acme runs on Meshery."
      }
    ],
    faqs: [
      {
        question: "How do I get an Acme account?",
        answer: "Email your manager or contact admin@acme.example."
      }
    ]
  }
};

const defaultOrgPayload = {
  id: "",
  theme: {
    logo: {}
  }
};

export const customDomainOrg = customDomainOrgPayload;

/**
 * The SAME Acme organization as {@link customDomainOrg}, in the shape the
 * public `GET /api/identity/orgs/by-domain` answers (the stored Organization:
 * branding under `metadata.preferences`, logos as `<view>.location`). The
 * flow-less auth pages (OAuth consent, error) read it there and project it
 * with utility/host-organization.ts; its jest test asserts the projection
 * equals `customDomainOrg`, so a spec on either page renders one brand.
 */
export function customDomainOrganization(domain: string) {
  const { theme, authBranding } = customDomainOrgPayload;
  const view = (location: string) => ({ svg: "", location });
  return {
    id: customDomainOrgPayload.id,
    name: customDomainOrgPayload.name,
    domain,
    metadata: {
      preferences: {
        theme: {
          id: theme.id,
          vars: theme.vars,
          logo: {
            desktopView: view(theme.logo.desktop),
            mobileView: view(theme.logo.mobile),
            darkDesktopView: view(theme.logo.darkDesktop)
          }
        },
        authBranding
      }
    }
  };
}

/** Build the canned /api/auth/flow JSON for the given options. */
export function mockAuthFlowResponse(opts: MockAuthFlowOptions) {
  const flowId = opts.flowId ?? "flow-id-1";
  return {
    flow: {
      // The real /api/auth/flow response echoes the (freshly minted or
      // fetched) flow id. useAuthFlow relies on it: on a cold load it
      // history.replaceState's `?flow=<id>` into the address bar so a refresh
      // rebinds to the same flow. Omitting it here left the URL flow-less and
      // broke the cold-load specs (architecture-guards flow-init).
      id: flowId,
      // Architectural invariant: action MUST be cloud-relative. Pre-fix
      // it pointed at Kratos directly; that was the violation that
      // closed PR #5208 had to undo. The submit-proxy URL is the only
      // thing the React page is allowed to POST to.
      action: `/api/auth/flow/submit?type=${encodeURIComponent(opts.type)}&id=${encodeURIComponent(flowId)}`,
      method: "POST",
      nodes: [
        ...(opts.nodes ?? defaultNodesForFlow(opts.type)),
        ...(opts.withPasskeys ? passkeyNodesForFlow(opts.type) : []),
        ...(opts.continueTo
          ? [
              {
                type: "a",
                group: "code",
                attributes: {
                  name: "continue",
                  type: "anchor",
                  value: opts.continueTo,
                  required: false,
                  disabled: false
                },
                messages: [],
                meta: {}
              }
            ]
          : [])
      ],
      messages: opts.messages ?? [],
      state: opts.state ?? ""
    },
    org: {
      ...(opts.customDomainOrg ? customDomainOrgPayload : defaultOrgPayload),
      // The server-computed host gate. Defaults to the server contract
      // (custom-domain org → false, canonical → true); specs name it
      // explicitly when testing the other side of the gate.
      passkeysAvailable: opts.passkeysAvailable ?? !opts.customDomainOrg
    },
    config: {
      recaptchaSiteKey: opts.recaptchaSiteKey ?? "",
      registrationEnabled: true,
      programName: opts.programName ?? "",
      // spamFilter is the JSON-encoded blockedDomains/blockedNames bag
      // registration.tsx::validateRegistration consumes. Empty string
      // when unset so the React page's `JSON.parse` short-circuits the
      // spam-filter branch with no allocations.
      spamFilter: opts.spamFilter ?? ""
    }
  };
}

export interface AuthFlowHandlerOptions extends MockAuthFlowOptions {
  /**
   * Where the submit proxy 303s on success. Defaults per FLOW TYPE (see
   * `defaultSuccessLocationFor`), not to one value for every flow: a
   * registration that lands on `/dashboard` describes no real server, and a
   * spec that then waits for `/registered` hangs for its whole timeout with
   * nothing in the failure naming the fixture as the cause.
   */
  submitSuccessLocation?: string;
  /** Override the submit response status. Default: 303. */
  submitStatus?: number;
  /**
   * Makes the submit fail validation the way the real proxy reports it: a
   * 303 back to the flow page (`/<page>?flow=<id>`, Kratos's ui_url), after
   * which `GET /api/auth/flow` serves this flow - the messages and echoed
   * values Kratos would return.
   */
  submitErrorFlow?: ReturnType<typeof mockAuthFlowResponse>;
  /**
   * Path (without leading slash) the submit-error 303 lands on.
   * Defaults to the flow page; the passkey settings page passes
   * `"reset"` because Kratos's settings `ui_url` is `/reset`, not the
   * page the flow renders on.
   */
  submitErrorPath?: string;
  /** Call when a request hits /api/auth/flow/init — return a Location URL. */
  initRedirect?: (request: Request) => string;
  /** Bag the helper writes every submit POST into (for assertions). */
  submitLog?: SubmitLogEntry[];
}

/**
 * Where a successful submit of `type` lands, mirroring the real server.
 *
 * This is per-flow rather than one blanket `/dashboard` because the blanket
 * default was silently wrong for exactly one flow and that cost the suite two
 * permanently-red tests. `email-signup.spec.ts`'s captcha case installed a
 * `registration` fixture without naming a landing, so the stub 303'd to
 * `/dashboard` while the test waited for `/registered` — it could never pass,
 * and it burned the full 60s timeout on every run rather than failing fast with
 * a legible message. Its three sibling cases all pass `/registered` explicitly,
 * so the fixture was the odd one out, not the assertion.
 *
 * Defaulting from the flow type removes the class: a registration fixture now
 * describes a registration server, and a spec only needs the override when it
 * is deliberately testing a non-default landing (a `?ref=` deep link, an
 * account-linking return).
 */
function defaultSuccessLocationFor(type: AuthFlowType): string {
  switch (type) {
    case "registration":
      // HandleRegistered's landing; `new_user` is set here and the verification
      // prompt lives on this page.
      return "/registered";
    case "login":
    case "recovery":
    case "verification":
    case "settings":
      // Left at the historical default deliberately. Only `registration` had a
      // demonstrated disagreement between fixture and assertion; every spec on
      // the other flows that asserts a landing already passes one explicitly
      // (password-reset names `/login`), so the default is unreachable there and
      // narrowing it would be a speculative change with no failure behind it.
      return "/dashboard";
  }
}

/**
 * Bundle of route handlers the auth-flow specs install via mockApi().
 * Wires:
 *   GET  /api/auth/flow            → canned flow JSON (mockAuthFlowResponse)
 *   GET  /api/auth/flow/init       → redirect to /<page>?flow=<id>
 *   POST /api/auth/flow/submit     → record + 303 (or fail)
 */
export function createAuthFlowHandlers(opts: AuthFlowHandlerOptions) {
  const flowId = opts.flowId ?? "flow-id-1";
  const successLocation =
    opts.submitSuccessLocation ?? defaultSuccessLocationFor(opts.type);
  const status = opts.submitStatus ?? 303;
  const submitLog = opts.submitLog;
  // Flips once a submit has failed validation; the flow Kratos then serves
  // carries the failure's messages.
  let failedValidation = false;

  return [
    async (request: Request) => {
      const url = new URL(request.url());
      if (url.pathname === "/api/auth/flow" && request.method() === "GET") {
        // body is the raw object — mockApi() in helpers/network.ts
        // JSON.stringifies any application/json response. Returning a
        // pre-stringified value here would double-encode the payload
        // and the React page would receive a JSON string instead of
        // an object after `response.json()`.
        return {
          status: 200,
          contentType: "application/json",
          body:
            failedValidation && opts.submitErrorFlow
              ? opts.submitErrorFlow
              : mockAuthFlowResponse(opts)
        };
      }

      if (url.pathname === "/api/auth/flow/init" && request.method() === "GET") {
        const type = url.searchParams.get("type") ?? opts.type;
        const dest =
          opts.initRedirect?.(request) ??
          `/${typeToPath(type as AuthFlowType)}?flow=${encodeURIComponent(flowId)}`;
        return {
          status: 302,
          contentType: "text/html",
          headers: { Location: dest },
          body: ""
        };
      }

      if (url.pathname === "/api/auth/flow/submit" && request.method() === "POST") {
        if (submitLog) {
          submitLog.push({
            url: request.url(),
            method: request.method(),
            postData: request.postData(),
            headers: request.headers()
          });
        }

        if (opts.submitErrorFlow) {
          // The proxy asks Kratos for HTML (Accept: text/html), so a
          // validation failure is never a 4xx body: Kratos 303s back to
          // its ui_url with the same flow id.
          failedValidation = true;
          return {
            status: 303,
            contentType: "text/html",
            headers: {
              Location: `/${opts.submitErrorPath ?? typeToPath(opts.type)}?flow=${encodeURIComponent(flowId)}`
            },
            body: ""
          };
        }

        return {
          status,
          contentType: "text/html",
          headers: { Location: successLocation },
          body: ""
        };
      }

      return undefined;
    }
  ];
}

// Map a flow type to the Next.js page URL the dev server can serve.
// All auth page types (login, registration, recovery, verification) now have
// canonical Next.js pages and are served directly by the dev server without
// proxying to the cloud server. The only exception is "settings", which maps
// to /password-reset (pages/password-reset.tsx) because production registers
// /reset on the cloud server and there is no pages/reset.tsx in Next.js.
const typeToPath = (type: AuthFlowType): string => {
  switch (type) {
    case "settings":
      return "password-reset";
    default:
      return type;
  }
};

/**
 * Architecture guard. Records every browser-issued request for the
 * lifetime of the test and asserts:
 *
 *  1. No request URL contains `kratos` — the browser must never reach
 *     Kratos directly. Pre-fix the React `useAuthFlow` hook redirected
 *     to `${KRATOS_BROWSER_URL}/self-service/<type>/browser` for flow
 *     init / expiry restart; this guard would have caught that the day
 *     it shipped.
 *  2. No request URL contains the legacy `/self-service/.../browser`
 *     path — covers the case where Kratos is reverse-proxied at a
 *     different prefix.
 *  3. Every POST goes to `/api/auth/flow/submit` — the only proxy URL
 *     the browser is allowed to POST auth state to.
 *  4. Returned function flushes the listener and returns the captured
 *     URLs so per-test additional assertions can run on the request
 *     trace.
 */
export function expectNoBrowserKratosRequest(page: Page): () => string[] {
  const urls: string[] = [];
  const listener = (req: Request) => urls.push(`${req.method()} ${req.url()}`);
  page.on("request", listener);

  return () => {
    page.off("request", listener);
    for (const entry of urls) {
      if (/kratos/i.test(entry)) {
        throw new Error(
          `architecture violation: browser issued a Kratos request — ${entry}. ` +
            `The browser must only ever talk to the cloud server; see docs/reference/authentication-and-identity.md.`
        );
      }
      if (
        /\/self-service\/(login|registration|recovery|verification|settings)\/browser/.test(
          entry
        )
      ) {
        throw new Error(
          `architecture violation: browser hit Kratos's /self-service/<type>/browser path — ${entry}. ` +
            `Flow init / restart must go through /api/auth/flow/init.`
        );
      }
      const [method, url] = entry.split(" ");
      if (method === "POST") {
        const path = new URL(url).pathname;
        // Allow non-auth POSTs (analytics, GraphQL, etc.) — the guard
        // is specifically about auth state. /api/auth/flow/submit is
        // the only legitimate auth POST target.
        if (path.includes("/auth") || path.includes("/self-service")) {
          if (path !== "/api/auth/flow/submit") {
            throw new Error(
              `architecture violation: browser POSTed auth state to ${url}. ` +
                `Only /api/auth/flow/submit is allowed.`
            );
          }
        }
      }
    }
    return urls;
  };
}

/**
 * Record every top-level NAVIGATION the browser performs, in order.
 *
 * WHY THIS EXISTS - and why counting route-handler invocations does not work
 * -------------------------------------------------------------------------
 * Playwright does NOT re-run `page.route()` interception for the target of a
 * redirect that a handler itself synthesised with `route.fulfill()`. Measured
 * directly against this suite's own server: a `**​/logout**` handler that
 * fulfils a 303 to `/logout?bounced=1` is invoked exactly ONCE, while
 * `page.on("request")` sees both `/logout` and `/logout?bounced=1`.
 *
 * That asymmetry made `logout.spec.ts`'s custom-domain case impossible to pass:
 * it asserted its handler had been hit at least twice, so it was red on every
 * run since it was written - and its companion `toHaveURL(/\/login/)` passed
 * for an unrelated reason (the un-intercepted second hop reached the real
 * export, whose SPA bounces an unauthenticated visitor to /login), which is why
 * the test read as "nearly passing" rather than as structurally broken.
 *
 * The redirect CHAIN is the thing under test, so observe it where it is
 * actually visible. `stopTrace()` returns the navigation URLs in order.
 *
 * REQUEST-level, and that choice is load-bearing. `page.on("framenavigated")`
 * reports where the main frame CAME TO REST, so a hop that redirected onward
 * never appears in it; the request stream sees every hop that was asked for.
 * Reach for this helper when the question is "which hosts did the chain touch"
 * (custom-domain-password-signin.spec.ts). `framenavigated` remains the right
 * instrument when the question is "which pages did the user actually land on",
 * which is why academy-enroll-deeplink.spec.ts uses it instead - that is a
 * deliberate difference, not drift.
 */
export function recordNavigations(page: Page): () => string[] {
  const urls: string[] = [];
  const listener = (req: Request) => {
    // TOP-LEVEL only. `isNavigationRequest()` is true for a SUB-FRAME navigation
    // too, and the one consumer reads every recorded URL as a hop the auth chain
    // took: an iframe or embed served by the canonical host during the sign-in
    // dance would be reported as an authorize leg that was not re-anchored -
    // a failure message describing something that did not happen. Every
    // `framenavigated` call site in this suite applies the same filter.
    if (req.isNavigationRequest() && req.frame() === page.mainFrame()) {
      urls.push(req.url());
    }
  };
  page.on("request", listener);
  return () => {
    page.off("request", listener);
    return urls;
  };
}

/**
 * Stub passthrough for a route the spec doesn't care about — used to
 * absorb browser navigations to /dashboard or /registered after a
 * successful submit. Returns a minimal HTML stub so the test can
 * assert the post-submit URL without rendering the full app.
 *
 * `**​/error` is deliberately NOT in this list. It used to be, and that made
 * the harness structurally incapable of catching the failure production
 * actually exhibits: /error is where a stranded auth flow lands, and
 * intercepting it meant every mocked spec saw a friendly stub instead of the
 * error page. A spec must be able to fail by landing on /error — that is the
 * whole signal. See issue #5766 and the auth e2e qualification report.
 */
export async function stubPostAuthLanding(page: Page) {
  for (const path of ["**/dashboard", "**/registered", "**/account"]) {
    await page.route(path, (route: Route) =>
      route.fulfill({
        status: 200,
        contentType: "text/html",
        body: `<!doctype html><html><body><main data-testid="landing">${path}</main></body></html>`
      })
    );
  }
}
