import { expect, test } from "@playwright/test";
import {
  createAuthFlowHandlers,
  expectNoBrowserKratosRequest,
  stubPostAuthLanding,
  type SubmitLogEntry
} from "../helpers/auth-flow";
import { createFallbackHandlers, mockApi } from "../helpers/network";

// passkey-registration.spec.ts covers WebAuthn passkey registration from
// the React page's perspective (issue #6478, spec §7.4 Tier A — mocked).
//
//   * canonical host: the "Register a passkey" trigger runs the same
//     spam-filter validation and captcha gate as the password path, then
//     submits `method=passkey` + `passkey_register=<credential JSON>`
//     with the full form body (traits + csrf_token) to the submit proxy.
//   * custom-domain org (`passkeysAvailable: false`): no trigger,
//     password + OIDC unchanged.
//
// `navigator.credentials.create` is stubbed per test (the real ceremony
// needs a platform authenticator — that is the live tier,
// passkey-live.spec.ts). Every test asserts the topology invariant: no
// browser→Kratos request.

const stubCreate = (outcome: "resolve" | "cancel") =>
  `
  const toBuffer = (bytes) => new Uint8Array(bytes).buffer;
  window.PublicKeyCredential = class {
    static async isConditionalMediationAvailable() { return false; }
  };
  Object.defineProperty(window.navigator, "credentials", {
    value: {
      get: async () => { throw new DOMException("Not implemented.", "NotSupportedError"); },
      create: async () => {
        ${outcome === "resolve" ? `
        return {
          id: "test-credential-id",
          rawId: toBuffer([1, 2, 3]),
          type: "public-key",
          response: {
            clientDataJSON: toBuffer([4, 5]),
            attestationObject: toBuffer([6, 7, 8]),
            getTransports: () => ["internal"]
          }
        };` : `
        throw new DOMException("The operation was cancelled.", "NotAllowedError");`}
      }
    },
    configurable: true
  });
  `;

const submitBodyParam = (body: string, name: string) =>
  new URLSearchParams(body).get(name);

const fillSignupForm = async (page: import("@playwright/test").Page) => {
  await page.locator("input[name='traits.name.first_name']").fill("Test");
  await page.locator("input[name='traits.name.last_name']").fill("User");
  await page.locator("input[name='traits.email']").fill("test-user@layer5.io");
  await page.locator("input[name='password']").fill("hunter2-hunter2");
};

for (const variant of ["main domain", "custom-domain org"] as const) {
  const isCustom = variant === "custom-domain org";

  test.describe(`passkey registration — ${variant}`, () => {
    test("renders the passkey trigger next to the password submit", async ({
      page
    }) => {
      const stopCapture = expectNoBrowserKratosRequest(page);
      await stubPostAuthLanding(page);
      await mockApi(page, [
        ...createAuthFlowHandlers({
          type: "registration",
          customDomainOrg: isCustom,
          withPasskeys: true
        }),
        ...createFallbackHandlers()
      ]);

      await page.goto("/registration?flow=flow-id-1", { waitUntil: "networkidle" });

      const trigger = page.locator("button.passkey-btn");
      if (isCustom) {
        await expect(trigger).toHaveCount(0);
      } else {
        await expect(trigger).toBeVisible();
        await expect(trigger).toHaveText(/Register a passkey/);
        await expect(trigger).toHaveAttribute("type", "button");
      }

      // Password submit + OIDC unchanged on both variants; the password
      // field stays required in v1 (passkey is an alternative first
      // factor, never a password replacement).
      await expect(page.locator("input[name='password']")).toBeVisible();
      await expect(
        page.locator("input[name='password']")
      ).toHaveAttribute("required", "");
      await expect(page.locator("button#submit")).toBeVisible();
      await expect(page.locator("button.social-auth-btn.github")).toBeVisible();

      stopCapture();
    });
  });
}

test.describe("passkey registration — canonical host ceremonies", () => {
  test("trigger submits method=passkey with the credential and the full form body", async ({
    page
  }) => {
    const stopCapture = expectNoBrowserKratosRequest(page);
    const submitLog: SubmitLogEntry[] = [];

    await page.addInitScript(stubCreate("resolve"));
    await stubPostAuthLanding(page);
    await mockApi(page, [
      ...createAuthFlowHandlers({
        type: "registration",
        withPasskeys: true,
        submitLog,
        submitSuccessLocation: "/registered"
      }),
      ...createFallbackHandlers()
    ]);

    await page.goto("/registration?flow=flow-id-1", { waitUntil: "networkidle" });
    await fillSignupForm(page);

    await page.locator("button.passkey-btn").click();
    await page.waitForURL("**/registered");

    expect(submitLog).toHaveLength(1);
    const body = submitLog[0].postData ?? "";
    expect(body).toContain("method=passkey");
    const credential = JSON.parse(
      submitBodyParam(body, "passkey_register") ?? "null"
    ) as Record<string, unknown>;
    expect(credential.id).toBe("test-credential-id");
    expect(credential.type).toBe("public-key");
    expect(credential.rawId).toBe("AQID");
    const response = credential.response as Record<string, unknown>;
    expect(response.attestationObject).toBe("BgcI");
    expect(response.transports).toEqual(["internal"]);
    // Full form body travels with the ceremony result.
    expect(body).toContain("traits.email=test-user%40layer5.io");
    expect(body).toContain("traits.name.first_name=Test");
    expect(body).toContain("traits.name.last_name=User");
    expect(body).toContain("password=hunter2-hunter2");
    expect(body).toContain("csrf_token=test-csrf-token");
    expect(submitLog[0].url).toMatch(
      /\/api\/auth\/flow\/submit\?type=registration&id=flow-id-1$/
    );

    stopCapture();
  });

  test("trigger is disabled until the captcha is solved", async ({ page }) => {
    const stopCapture = expectNoBrowserKratosRequest(page);
    await stubPostAuthLanding(page);
    await mockApi(page, [
      ...createAuthFlowHandlers({
        type: "registration",
        withPasskeys: true,
        recaptchaSiteKey: "test-site-key"
      }),
      ...createFallbackHandlers()
    ]);

    await page.goto("/registration?flow=flow-id-1", { waitUntil: "networkidle" });

    // Same forceSubmitDisabled treatment as the password submit: the
    // trigger cannot bypass the captcha gate.
    await expect(page.locator("button.passkey-btn")).toBeDisabled();
    await expect(page.locator("button#submit")).toBeDisabled();

    stopCapture();
  });

  test("trigger runs the spam filter like the password path", async ({ page }) => {
    const stopCapture = expectNoBrowserKratosRequest(page);
    const submitLog: SubmitLogEntry[] = [];

    await page.addInitScript(stubCreate("resolve"));
    await stubPostAuthLanding(page);
    await mockApi(page, [
      ...createAuthFlowHandlers({
        type: "registration",
        withPasskeys: true,
        submitLog,
        submitSuccessLocation: "/registered",
        spamFilter: JSON.stringify({
          blockedDomains: ["spam.example"],
          blockedNames: []
        })
      }),
      ...createFallbackHandlers()
    ]);

    await page.goto("/registration?flow=flow-id-1", { waitUntil: "networkidle" });
    await page.locator("input[name='traits.name.first_name']").fill("Test");
    await page.locator("input[name='traits.name.last_name']").fill("User");
    await page.locator("input[name='traits.email']").fill("test-user@spam.example");
    await page.locator("input[name='password']").fill("hunter2-hunter2");

    await page.locator("button.passkey-btn").click();
    await expect(
      page.getByText("Invalid email address or domain not allowed.")
    ).toBeVisible();

    expect(submitLog).toHaveLength(0);
    await expect(page).toHaveURL(/\/registration\?flow=flow-id-1$/);

    stopCapture();
  });

  test("a cancelled ceremony submits nothing and leaves the form typed", async ({
    page
  }) => {
    const stopCapture = expectNoBrowserKratosRequest(page);
    const submitLog: SubmitLogEntry[] = [];

    await page.addInitScript(stubCreate("cancel"));
    await stubPostAuthLanding(page);
    await mockApi(page, [
      ...createAuthFlowHandlers({
        type: "registration",
        withPasskeys: true,
        submitLog,
        submitSuccessLocation: "/registered"
      }),
      ...createFallbackHandlers()
    ]);

    await page.goto("/registration?flow=flow-id-1", { waitUntil: "networkidle" });
    await fillSignupForm(page);

    await page.locator("button.passkey-btn").click();
    await page.waitForTimeout(500);

    expect(submitLog).toHaveLength(0);
    await expect(page).toHaveURL(/\/registration\?flow=flow-id-1$/);
    // Nothing the user typed is lost.
    await expect(page.locator("input[name='traits.email']")).toHaveValue(
      "test-user@layer5.io"
    );

    stopCapture();
  });

  test("Enter still submits the password method", async ({ page }) => {
    const stopCapture = expectNoBrowserKratosRequest(page);
    const submitLog: SubmitLogEntry[] = [];

    await page.addInitScript(stubCreate("resolve"));
    await stubPostAuthLanding(page);
    await mockApi(page, [
      ...createAuthFlowHandlers({
        type: "registration",
        withPasskeys: true,
        submitLog,
        submitSuccessLocation: "/registered"
      }),
      ...createFallbackHandlers()
    ]);

    await page.goto("/registration?flow=flow-id-1", { waitUntil: "networkidle" });
    await fillSignupForm(page);
    await page.locator("input[name='password']").press("Enter");
    await page.waitForURL("**/registered");

    expect(submitLog).toHaveLength(1);
    expect(submitLog[0].postData ?? "").toContain("method=password");
    expect(submitLog[0].postData ?? "").not.toContain("passkey_register");

    stopCapture();
  });
});
